package com.example.debloater

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object Sh {
    /** Команда с правами shell через Shizuku. Не вызывать из главного потока. */
    fun run(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Throwable) {
        "ERR: ${e.message}"
    }
}

data class AppItem(
    val pkg: String,
    val label: String,
    val system: Boolean,
    var installed: Boolean,
    var enabled: Boolean,
    val critical: Boolean
)

object Ops {
    fun freeze(pkg: String) = Sh.run("am force-stop $pkg; pm disable-user --user 0 $pkg")
    fun unfreeze(pkg: String) = Sh.run("pm enable --user 0 $pkg")
    fun remove(pkg: String, system: Boolean) =
        Sh.run("am force-stop $pkg; pm uninstall ${if (system) "-k " else ""}--user 0 $pkg")
    fun restore(pkg: String) =
        Sh.run("cmd package install-existing --user 0 $pkg; pm enable --user 0 $pkg")

    fun ok(out: String) = out.contains("Success", true) || out.contains("installed for user", true) ||
        out.contains("new state", true)
}

object Repo {
    // Защищённые пакеты: их отключение может сломать систему, поэтому действия для них закрыты.
    private val critical = listOf(
        "android", "com.android.systemui", "com.android.settings", "com.android.phone",
        "com.android.providers.", "com.android.launcher", "com.android.packageinstaller",
        "com.google.android.packageinstaller", "com.android.permissioncontroller",
        "com.google.android.permissioncontroller", "com.android.shell", "com.android.server",
        "com.android.inputmethod", "com.android.bluetooth", "com.android.nfc",
        "com.android.networkstack", "com.android.wifi", "com.android.cellbroadcast",
        "com.android.vending", "com.google.android.gms", "com.google.android.gsf",
        "com.bbk.launcher2", "com.vivo.launcher", "com.vivo.permissionmanager",
        "com.vivo.upslide", "com.android.stk", "com.android.managedprovisioning",
        "com.android.keychain", "com.android.certinstaller", "com.android.webview",
        "com.google.android.webview", "com.android.mms.service", "com.android.telephony",
        "com.android.emergency", "com.android.externalstorage", "com.android.documentsui",
        "com.android.mtp", "com.android.carrierconfig", "moe.shizuku.privileged.api",
        "com.example.debloater"
    )

    fun isCritical(pkg: String) = pkg == "android" || critical.any { it != "android" && pkg.startsWith(it) }

    private fun toItem(pm: PackageManager, ai: ApplicationInfo) = AppItem(
        pkg = ai.packageName,
        label = ai.loadLabel(pm).toString(),
        system = (ai.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0,
        installed = (ai.flags and ApplicationInfo.FLAG_INSTALLED) != 0,
        enabled = ai.enabled,
        critical = isCritical(ai.packageName)
    )

    @Suppress("DEPRECATION")
    fun load(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(PackageManager.MATCH_UNINSTALLED_PACKAGES)
            .map { toItem(pm, it) }
            .sortedBy { it.label.lowercase() }
    }

    @Suppress("DEPRECATION")
    fun refresh(ctx: Context, a: AppItem) {
        val pm = ctx.packageManager
        try {
            val ai = pm.getApplicationInfo(a.pkg, PackageManager.MATCH_UNINSTALLED_PACKAGES)
            a.installed = (ai.flags and ApplicationInfo.FLAG_INSTALLED) != 0
            a.enabled = ai.enabled
        } catch (_: Exception) {}
    }
}
