package com.example.debloater

import android.animation.ValueAnimator
import android.app.Activity
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Outline
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var pal: Palette
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var list: RecyclerView
    private lateinit var adapter: AppAdapter
    private lateinit var statusPill: TextView
    private lateinit var countText: TextView
    private lateinit var emptyText: TextView
    private lateinit var search: EditText
    private val chips = mutableListOf<TextView>()

    // шторка
    private lateinit var sheetLayer: FrameLayout
    private lateinit var scrim: View
    private lateinit var panel: LinearLayout
    private lateinit var sIcon: ImageView
    private lateinit var sName: TextView
    private lateinit var sPkg: TextView
    private lateinit var sState: TextView
    private lateinit var sInfo: TextView
    private lateinit var btnMain: TextView
    private lateinit var btnDanger: TextView
    private lateinit var snackView: TextView

    private val ui = Handler(Looper.getMainLooper())
    private var all: List<AppItem> = emptyList()
    private var filter = 0
    private var query = ""
    private var topInset = 0
    private var botInset = 0
    private var current: AppItem? = null
    private var confirmDelete = false
    private var busy = false
    private var sheetOpen = false
    private var panelAnim: SpringAnimation? = null
    private var blurAnim: ValueAnimator? = null
    private var curBlur = 0f

    private val icons = LruCache<String, Drawable>(300)
    private val pool = Executors.newFixedThreadPool(3)
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { updateStatus() } }
    private val hideSnack = Runnable { spring(snackView, DynamicAnimation.TRANSLATION_Y, dp(160).toFloat(), 400f, 1f) }

    companion object { const val FREEZE = 0; const val UNFREEZE = 1; const val DELETE = 2; const val RESTORE = 3 }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pal = Palette(resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES)
        setupWindow()
        buildUi()
        Shizuku.addRequestPermissionResultListener(permListener)
        reload()
    }

    override fun onDestroy() { Shizuku.removeRequestPermissionResultListener(permListener); super.onDestroy() }
    override fun onResume() { super.onResume(); updateStatus() }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() { if (sheetOpen) closeSheet() else super.onBackPressed() }

    @Suppress("DEPRECATION")
    private fun setupWindow() {
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULL_SCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (!pal.dark) {
            f = f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = f
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        setTextColor(color)
        typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        if (bold) paint.isFakeBoldText = false
    }

    // ---------------- интерфейс ----------------

    @Suppress("DEPRECATION")
    private fun buildUi() {
        root = FrameLayout(this)
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(pal.bgTop, pal.bgBottom))
        root.addView(BlobView(this, pal.dark), FrameLayout.LayoutParams(MATCH, MATCH))

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))

        // заголовок
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(10))
        }
        val title = tv("Очистка", 34f, pal.text, true).apply { paint.isFakeBoldText = true }
        countText = tv("", 14f, pal.sub)
        statusPill = tv("", 13f, pal.sub).apply {
            background = glass(this@MainActivity, pal, dpf(100f))
            setPadding(dp(14), dp(7), dp(14), dp(7))
        }
        header.addView(title)
        header.addView(countText, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(2) })
        header.addView(statusPill, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(12) })
        content.addView(header)

        // поиск
        search = EditText(this).apply {
            hint = "Поиск приложений"
            setHintTextColor(pal.sub); setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            inputType = InputType.TYPE_CLASS_TEXT
            isSingleLine = true
            background = glass(this@MainActivity, pal, dpf(18f))
            setPadding(dp(18), dp(13), dp(18), dp(13))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; applyFilter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        content.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(20), dp(4), dp(20), dp(10)) })

        // фильтры
        val names = listOf("Все", "Системные", "Мои", "Заморожены", "Удалены")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(20), 0, dp(20), 0) }
        names.forEachIndexed { i, n ->
            val chip = tv(n, 14f, pal.text, true).apply {
                setPadding(dp(16), dp(9), dp(16), dp(9))
                setOnClickListener {
                    filter = i
                    chips.forEach { styleChip(it, chips.indexOf(it) == filter) }
                    scaleX = 0.88f; scaleY = 0.88f
                    spring(this, DynamicAnimation.SCALE_X, 1f, 500f, 0.45f)
                    spring(this, DynamicAnimation.SCALE_Y, 1f, 500f, 0.45f)
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    applyFilter()
                }
            }
            chips.add(chip)
            row.addView(chip, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        chips.forEachIndexed { i, c -> styleChip(c, i == 0) }
        content.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; addView(row)
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })

        // список
        adapter = AppAdapter()
        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        emptyText = tv("Здесь пусто", 15f, pal.sub).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        val wrap = FrameLayout(this)
        wrap.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))
        wrap.addView(emptyText, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER))
        content.addView(wrap, LinearLayout.LayoutParams(MATCH, 0, 1f))

        buildSheet()

        snackView = tv("", 14f, pal.text, true).apply {
            background = glass(this@MainActivity, pal, dpf(22f), strong = true)
            setPadding(dp(20), dp(13), dp(20), dp(13))
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        root.addView(snackView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        root.setOnApplyWindowInsetsListener { _, ins ->
            topInset = ins.systemWindowInsetTop
            botInset = ins.systemWindowInsetBottom
            content.setPadding(0, topInset, 0, 0)
            list.setPadding(dp(20), dp(4), dp(20), botInset + dp(24))
            panel.setPadding(dp(22), 0, dp(22), botInset + dp(20))
            (snackView.layoutParams as FrameLayout.LayoutParams).bottomMargin = botInset + dp(24)
            ins
        }
        setContentView(root)
        root.requestApplyInsets()
    }

    private fun styleChip(c: TextView, selected: Boolean) {
        if (selected) { c.background = solid(pal.accent, dpf(100f)); c.setTextColor(Color.WHITE) }
        else { c.background = glass(this, pal, dpf(100f)); c.setTextColor(pal.text) }
    }

    private fun styleBtn(b: TextView, kind: Int) {
        // 0 — стекло, 1 — акцент, 2 — красный
        when (kind) {
            1 -> { b.background = solid(pal.accent, dpf(18f)); b.setTextColor(Color.WHITE) }
            2 -> { b.background = solid(Color.argb(if (pal.dark) 60 else 38, 255, 69, 58), dpf(18f)); b.setTextColor(pal.danger) }
            else -> { b.background = glass(this, pal, dpf(18f)); b.setTextColor(pal.text) }
        }
    }

    private fun press(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    spring(view, DynamicAnimation.SCALE_X, 0.96f, 800f, 0.8f)
                    spring(view, DynamicAnimation.SCALE_Y, 0.96f, 800f, 0.8f)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    spring(view, DynamicAnimation.SCALE_X, 1f, 450f, 0.45f)
                    spring(view, DynamicAnimation.SCALE_Y, 1f, 450f, 0.45f)
                }
            }
            false
        }
    }

    // ---------------- шторка ----------------

    @Suppress("ClickableViewAccessibility")
    private fun buildSheet() {
        sheetLayer = FrameLayout(this).apply { visibility = View.GONE }
        scrim = View(this).apply {
            setBackgroundColor(Color.argb(if (pal.dark) 120 else 70, 0, 0, 0)); alpha = 0f
            setOnClickListener { closeSheet() }
        }
        sheetLayer.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(this@MainActivity, pal, dpf(32f), strong = true, top = true)
            isClickable = true
        }
        sheetLayer.addView(panel, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        // ручка: тянется вниз, чтобы закрыть
        val handle = FrameLayout(this)
        handle.addView(View(this).apply { background = solid(pal.sub, dpf(3f)); alpha = 0.5f },
            FrameLayout.LayoutParams(dp(40), dp(5), Gravity.CENTER))
        var tracker: VelocityTracker? = null
        var downY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY; panelAnim?.cancel()
                    tracker?.recycle(); tracker = VelocityTracker.obtain(); tracker?.addMovement(e)
                }
                MotionEvent.ACTION_MOVE -> {
                    tracker?.addMovement(e)
                    val d = e.rawY - downY
                    panel.translationY = if (d > 0) d else d * 0.2f
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    tracker?.computeCurrentVelocity(1000)
                    val vy = tracker?.yVelocity ?: 0f
                    if (panel.translationY > dp(110) || vy > 1500f) closeSheet(vy)
                    else panelAnim = spring(panel, DynamicAnimation.TRANSLATION_Y, 0f, 380f, 0.7f, vy)
                    tracker?.recycle(); tracker = null
                }
            }
            true
        }
        panel.addView(handle, LinearLayout.LayoutParams(MATCH, dp(32)))

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sIcon = ImageView(this).apply { roundIcon(this, 16f) }
        val tcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sName = tv("", 21f, pal.text, true).apply { paint.isFakeBoldText = true; maxLines = 2 }
        sPkg = tv("", 12f, pal.sub)
        tcol.addView(sName); tcol.addView(sPkg)
        top.addView(sIcon, LinearLayout.LayoutParams(dp(60), dp(60)))
        top.addView(tcol, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })
        panel.addView(top)

        sState = tv("", 13f, pal.text, true).apply {
            background = glass(this@MainActivity, pal, dpf(100f))
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }
        panel.addView(sState, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(16) })
        sInfo = tv("", 14f, pal.sub)
        panel.addView(sInfo, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        btnMain = tv("", 16f, pal.text, true).apply { gravity = Gravity.CENTER }
        btnDanger = tv("", 16f, pal.danger, true).apply { gravity = Gravity.CENTER }
        press(btnMain); press(btnDanger)
        btnMain.setOnClickListener { act(if (current?.installed == false) RESTORE else if (current?.enabled == false) UNFREEZE else FREEZE) }
        btnDanger.setOnClickListener { act(DELETE) }
        panel.addView(btnMain, LinearLayout.LayoutParams(MATCH, dp(54)).apply { topMargin = dp(20) })
        panel.addView(btnDanger, LinearLayout.LayoutParams(MATCH, dp(54)).apply { topMargin = dp(10) })

        root.addView(sheetLayer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun roundIcon(iv: ImageView, r: Float) {
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dpf(r)) }
        }
        iv.clipToOutline = true
    }

    private fun fillSheet() {
        val a = current ?: return
        sName.text = a.label
        sPkg.text = a.pkg
        loadIcon(a.pkg, sIcon)
        val removed = !a.installed
        val frozen = a.installed && !a.enabled
        val kind = if (a.system) "Системное" else "Пользовательское"
        val stateTxt = when { removed -> "Удалено"; frozen -> "Заморожено"; else -> "Активно" }
        sState.text = "$kind  ·  $stateTxt"
        sState.setTextColor(when { removed -> pal.danger; frozen -> pal.warn; else -> pal.ok })
        val ready = shizukuReady()
        sInfo.text = when {
            a.critical -> "Защищённое приложение: его отключение может нарушить работу телефона, поэтому действия недоступны."
            !ready -> "Нужен доступ Shizuku. Запустите Shizuku и нажмите на статус вверху экрана."
            removed -> "Приложение убрано для вашего профиля, но осталось в системе. Его можно вернуть."
            frozen -> "Приложение заморожено: не запускается и не работает в фоне. Разморозить можно в любой момент."
            a.system -> "Системное приложение. Заморозка безопасна и обратима. Удаление скрывает его, данные сохраняются, вернуть можно здесь же."
            else -> "Пользовательское приложение. При удалении его данные будут стёрты."
        }
        btnMain.visibility = if (a.critical) View.GONE else View.VISIBLE
        btnDanger.visibility = if (a.critical || removed) View.GONE else View.VISIBLE
        btnMain.text = if (busy) "Выполняю…" else when { removed -> "Восстановить"; frozen -> "Разморозить"; else -> "Заморозить" }
        btnDanger.text = if (busy) "Выполняю…" else "Удалить"
        styleBtn(btnMain, if (removed || frozen) 1 else 0)
        styleBtn(btnDanger, 2)
        btnMain.alpha = if (ready) 1f else 0.4f
        btnDanger.alpha = if (ready) 1f else 0.4f
    }

    private fun openSheet(a: AppItem) {
        current = a; confirmDelete = false; busy = false
        fillSheet()
        sheetOpen = true
        sheetLayer.visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(220).start()
        panelAnim?.cancel()
        panel.translationY = root.height.toFloat()
        panelAnim = spring(panel, DynamicAnimation.TRANSLATION_Y, 0f, 260f, 0.78f)
        animBlur(if (Build.VERSION.SDK_INT >= 31) 26f else 0f)
    }

    private fun closeSheet(vel: Float = 0f) {
        if (!sheetOpen) return
        sheetOpen = false
        scrim.animate().alpha(0f).setDuration(220).start()
        panelAnim?.cancel()
        panelAnim = spring(panel, DynamicAnimation.TRANSLATION_Y, root.height.toFloat(), 300f, 1f, vel) {
            if (!sheetOpen) sheetLayer.visibility = View.GONE
        }
        animBlur(0f)
    }

    private fun animBlur(to: Float) {
        if (Build.VERSION.SDK_INT < 31) return
        blurAnim?.cancel()
        blurAnim = ValueAnimator.ofFloat(curBlur, to).apply {
            duration = 380
            addUpdateListener {
                curBlur = it.animatedValue as Float
                content.setRenderEffect(
                    if (curBlur < 0.5f) null else RenderEffect.createBlurEffect(curBlur, curBlur, Shader.TileMode.CLAMP)
                )
            }
            start()
        }
    }

    private fun snack(msg: String) {
        snackView.text = msg
        snackView.visibility = View.VISIBLE
        snackView.translationY = dp(140).toFloat()
        spring(snackView, DynamicAnimation.TRANSLATION_Y, 0f, 350f, 0.6f)
        ui.removeCallbacks(hideSnack)
        ui.postDelayed(hideSnack, 2800)
    }

    private fun shake(v: View) {
        v.translationX = dp(16).toFloat()
        spring(v, DynamicAnimation.TRANSLATION_X, 0f, 700f, 0.25f)
    }

    // ---------------- действия ----------------

    private fun act(kind: Int) {
        val a = current ?: return
        if (busy || a.critical) return
        if (!shizukuReady()) { snack("Нужен доступ Shizuku"); shake(btnMain); return }
        if (kind == DELETE && !confirmDelete) {
            confirmDelete = true
            btnDanger.text = "Нажмите ещё раз для удаления"
            btnDanger.background = solid(pal.danger, dpf(18f)); btnDanger.setTextColor(Color.WHITE)
            shake(btnDanger)
            ui.postDelayed({ if (confirmDelete && !busy) { confirmDelete = false; fillSheet() } }, 3000)
            return
        }
        busy = true; confirmDelete = false
        fillSheet()
        Thread {
            val out = when (kind) {
                FREEZE -> Ops.freeze(a.pkg)
                UNFREEZE -> Ops.unfreeze(a.pkg)
                DELETE -> Ops.remove(a.pkg, a.system)
                else -> Ops.restore(a.pkg)
            }
            val ok = Ops.ok(out)
            if (ok) Repo.refresh(this, a)
            runOnUiThread {
                busy = false
                fillSheet()
                if (ok) {
                    applyFilter()
                    snack(when (kind) { FREEZE -> "Заморожено"; UNFREEZE -> "Разморожено"; DELETE -> "Удалено"; else -> "Восстановлено" })
                } else {
                    shake(btnMain)
                    snack("Не получилось: " + out.trim().take(70))
                }
            }
        }.start()
    }

    // ---------------- данные ----------------

    private fun shizukuRunning() = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
    private fun shizukuGranted() = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
    private fun shizukuReady() = shizukuRunning() && shizukuGranted()

    private fun updateStatus() {
        val run = shizukuRunning(); val ok = run && shizukuGranted()
        statusPill.text = when { ok -> "●  Shizuku подключён"; run -> "●  Нажмите, чтобы дать доступ"; else -> "●  Shizuku не запущен" }
        statusPill.setTextColor(when { ok -> pal.ok; run -> pal.warn; else -> pal.danger })
        statusPill.setOnClickListener {
            if (run && !ok) Shizuku.requestPermission(1)
            else if (!run) packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
        }
        if (sheetOpen) fillSheet()
    }

    private fun reload() {
        Thread {
            val l = Repo.load(this)
            runOnUiThread { all = l; applyFilter() }
        }.start()
    }

    private fun applyFilter() {
        val q = query.trim().lowercase()
        val l = all.filter {
            when (filter) {
                0 -> it.installed
                1 -> it.installed && it.system
                2 -> it.installed && !it.system
                3 -> it.installed && !it.enabled
                else -> !it.installed
            }
        }.filter { q.isEmpty() || it.label.lowercase().contains(q) || it.pkg.contains(q) }
        adapter.submit(l)
        countText.text = "Приложений: ${l.size}"
        emptyText.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun loadIcon(pkg: String, iv: ImageView) {
        iv.tag = pkg
        val c = icons.get(pkg)
        if (c != null) { iv.setImageDrawable(c); return }
        iv.setImageDrawable(null)
        pool.execute {
            @Suppress("DEPRECATION")
            val d = try {
                packageManager.getApplicationInfo(pkg, PackageManager.MATCH_UNINSTALLED_PACKAGES).loadIcon(packageManager)
            } catch (_: Exception) { null }
            if (d != null) {
                icons.put(pkg, d)
                runOnUiThread {
                    if (iv.tag == pkg) { iv.alpha = 0f; iv.setImageDrawable(d); iv.animate().alpha(1f).setDuration(160).start() }
                }
            }
        }
    }

    // ---------------- список ----------------

    inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        private var items: List<AppItem> = emptyList()
        private var lastAnim = -1

        inner class VH(
            val card: LinearLayout, val icon: ImageView, val name: TextView,
            val pkg: TextView, val state: TextView
        ) : RecyclerView.ViewHolder(card)

        fun submit(l: List<AppItem>) { items = l; lastAnim = -1; notifyDataSetChanged() }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val card = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = glass(this@MainActivity, pal, dpf(22f))
                setPadding(dp(14), dp(12), dp(16), dp(12))
                layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) }
            }
            val icon = ImageView(this@MainActivity); roundIcon(icon, 12f)
            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            val name = tv("", 16f, pal.text, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
            val pkg = tv("", 12f, pal.sub).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }
            col.addView(name); col.addView(pkg)
            val state = tv("", 12f, pal.sub, true)
            card.addView(icon, LinearLayout.LayoutParams(dp(46), dp(46)))
            card.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14); rightMargin = dp(8) })
            card.addView(state)
            press(card)
            return VH(card, icon, name, pkg, state)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val a = items[pos]
            h.name.text = a.label
            h.pkg.text = a.pkg
            loadIcon(a.pkg, h.icon)
            when {
                !a.installed -> { h.state.text = "Удалено"; h.state.setTextColor(pal.danger) }
                !a.enabled -> { h.state.text = "Заморожено"; h.state.setTextColor(pal.warn) }
                a.critical -> { h.state.text = "Защита"; h.state.setTextColor(pal.sub) }
                else -> { h.state.text = "Активно"; h.state.setTextColor(pal.ok) }
            }
            h.card.setOnClickListener { openSheet(a) }
            // появление пружиной
            val v = h.card
            v.animate().cancel()
            if (pos > lastAnim) {
                lastAnim = pos
                v.alpha = 0f; v.translationY = dp(46).toFloat()
                ui.postDelayed({
                    v.animate().alpha(1f).setDuration(200).start()
                    spring(v, DynamicAnimation.TRANSLATION_Y, 0f, 300f, 0.68f)
                }, minOf(pos, 9) * 30L)
            } else { v.alpha = 1f; v.translationY = 0f }
        }
    }
}
