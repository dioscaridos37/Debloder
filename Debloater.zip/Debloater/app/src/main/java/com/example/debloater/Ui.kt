package com.example.debloater

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.View
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import kotlin.math.cos
import kotlin.math.sin

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

class Palette(val dark: Boolean) {
    val bgTop = Color.parseColor(if (dark) "#0B0D15" else "#E6EFFF")
    val bgBottom = Color.parseColor(if (dark) "#1B1233" else "#F6ECFF")
    val text = Color.parseColor(if (dark) "#F2F4F8" else "#14161A")
    val sub = Color.parseColor(if (dark) "#9AA2B2" else "#6B7280")
    val accent = Color.parseColor(if (dark) "#5B8CFF" else "#2D6BFF")
    val ok = Color.parseColor("#30C964")
    val warn = Color.parseColor("#FF9F0A")
    val danger = Color.parseColor("#FF453A")
    val fill = if (dark) Color.argb(34, 255, 255, 255) else Color.argb(150, 255, 255, 255)
    val fillStrong = if (dark) Color.argb(60, 30, 36, 60) else Color.argb(215, 255, 255, 255)
    val stroke = if (dark) Color.argb(60, 255, 255, 255) else Color.argb(210, 255, 255, 255)
    val sheen1 = if (dark) Color.argb(40, 255, 255, 255) else Color.argb(110, 255, 255, 255)
    val sheen2 = if (dark) Color.argb(6, 255, 255, 255) else Color.argb(10, 255, 255, 255)
}

/** Стекло: полупрозрачная заливка + блик + светлая обводка. */
fun glass(ctx: Context, p: Palette, r: Float, strong: Boolean = false, top: Boolean = false): Drawable {
    val radii = if (top) floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) else FloatArray(8) { r }
    val base = GradientDrawable().apply {
        setColor(if (strong) p.fillStrong else p.fill)
        cornerRadii = radii
        setStroke(ctx.dp(1), p.stroke)
    }
    val sheen = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.sheen1, p.sheen2)).apply {
        cornerRadii = radii
    }
    return LayerDrawable(arrayOf(base, sheen))
}

fun solid(color: Int, r: Float): Drawable = GradientDrawable().apply { setColor(color); cornerRadius = r }

/** Пружина для свойства вида. */
fun spring(
    v: View, p: DynamicAnimation.ViewProperty, to: Float,
    stiff: Float = 380f, damp: Float = 0.62f, vel: Float = 0f, end: (() -> Unit)? = null
): SpringAnimation {
    val a = SpringAnimation(v, p, to)
    a.spring.setStiffness(stiff).setDampingRatio(damp)
    if (vel != 0f) a.setStartVelocity(vel)
    if (end != null) a.addEndListener { _, c, _, _ -> if (!c) end() }
    a.start()
    return a
}

/** Мягкие цветные пятна на фоне, медленно плывут. Под полупрозрачным стеклом создают глубину. */
class BlobView(ctx: Context, dark: Boolean) : View(ctx) {
    private val cols = if (dark)
        intArrayOf(Color.parseColor("#4A78FF"), Color.parseColor("#9A5BFF"), Color.parseColor("#14B8C8"))
    else
        intArrayOf(Color.parseColor("#8DBBFF"), Color.parseColor("#CDA8FF"), Color.parseColor("#9DE8F2"))
    private val paints = Array(3) { Paint(Paint.ANTI_ALIAS_FLAG) }
    private var phase = 0f
    private var radius = 1f
    private val anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 22000; repeatCount = ValueAnimator.INFINITE; interpolator = android.view.animation.LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        radius = w * 0.85f
        for (i in 0..2) {
            val c = cols[i]
            paints[i].shader = RadialGradient(
                0f, 0f, radius,
                intArrayOf(Color.argb(150, Color.red(c), Color.green(c), Color.blue(c)), Color.argb(0, Color.red(c), Color.green(c), Color.blue(c))),
                null, Shader.TileMode.CLAMP
            )
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val pos = arrayOf(
            floatArrayOf(w * (0.15f + 0.10f * sin(phase)), h * (0.12f + 0.05f * cos(phase))),
            floatArrayOf(w * (0.95f + 0.08f * cos(phase * 0.8f)), h * (0.48f + 0.06f * sin(phase * 0.8f))),
            floatArrayOf(w * (0.25f + 0.10f * sin(phase * 1.3f)), h * (0.95f + 0.04f * cos(phase * 1.3f)))
        )
        for (i in 0..2) {
            c.save(); c.translate(pos[i][0], pos[i][1]); c.drawCircle(0f, 0f, radius, paints[i]); c.restore()
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
}
